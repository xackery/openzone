======================================================
= EXTENDED DOCUMENT OBJECT MODEL GENERAL INFORMATION =
======================================================


What is the Extended Document Object Model Package?
---------------------------------------------------

The 'Extended Document Object Model' Package for Delphi
and Kylix contains several functions, classes, and 
components which support the processing of XML documents. 
It allows to represent an XML document by Delphi objects 
which reproduce the structure and content of the XML 
document in an object tree. XML parser components contained 
in the package make it easy to transform any XML file or XML
string into such an object tree, which then can be modified
or evaluated by a great number of available functions. A 
detailed documentation is included. 


Website
-------

The project's home is located at the Open XML website: 
"http://www.philo.de/xml/".


Supported Delphi/Kylix Versions
-------------------------------

The Extended Document Object Model Package works with 
Delphi 4, 6, 7, 8, 2005 and Kylix 3.  It might also work 
with later Delphi or earlier Kylix versions, but that has
not been tested.


Requirements
------------

The latest version of the Open XML Utilities Library must be
installed on your system. You can download it from the Open 
XML website.


Bugs
----

Currently, there are no bugs known.


Contents of the Zip-Archive
---------------------------

All files needed for installing the Extended Document Object 
Model can be found in a zip-archive which can be downloaded 
via the Open XML website. This archive contains the following 
files and directories:

Documentation Files:

* HISTORY.txt   
  The history of development of the 'Extended Document Object 
  Model' including a list of all deviations from earlier 
  version.

* INSTALL.txt   
  The installation instructions.

* LICENSE.txt   
  The license of the 'Extended Document Object Model'.

* README.txt    
  Obviously the file your are currently reading.

* UPGRADE.txt   
  Hints, how to upgrade if you had installed any previous 
  version of the 'Extended Document Object Model'.
                

Code Files:

* Xdom_3_2.pas
  The main XDOM source code.

* Xdom_3_2.dcr
  The bit maps for the Delphi component's palette.
  
* XdomPropertyEditor_3_2.pas
  The source code of XDOM's property editor.

* XdomPropertyEditor_3_2.dfm
  The Delphi form file of XDOM's property editor.

* XdomPropertyEditor_3_2.xfm
  The Kylix form file of XDOM's property editor.

* XdomReg_3_2.pas
  The source code for component registration.

* various *.dpk files
  The package files for installing XDOM in the different 
  Delphi/Kylix versions.


Directories:

* add_ons
  A folder containing additional components and classes. 
  Please read the README.txt files in the sub-directories 
  for further instructions.

* examples
  A folder containing sample XDOM applications for Delphi.

* manual
  A folder which holds a detailed manual of the 'Extended 
  Document Object Model' as an XML-text.
