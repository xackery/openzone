When loading an example project some Delphi versions
show a message box "Cannot find resource file ...".
Just ignore this message and click "OK".  Delphi
automatically creates a default resource file, then.